function loc() {
    document.getElementById("input2").style.visibility="visible";
    document.getElementById("input2").style.display="block";
    document.getElementById("input2").required = true;
    document.getElementById("emailbtn").style.display="none";required=""
}