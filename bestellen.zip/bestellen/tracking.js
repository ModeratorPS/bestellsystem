function loc() {
    document.getElementById("deinebestellung").style.visibility="hidden";
}